#include "PE.hpp"

void GameSpace::obj::setPosition(float x, float y, float z)
{
    if (gs->getSize().X >= x && x > (-1 * (gs->getSize().X)))
    {
        this->x = x;
    }
    if (gs->getSize().Y > y && y > (-1 * (gs->getSize().Y)))
    {
        this->y = y;
    }
    if (gs->getSize().Z > z && z > (-1 * (gs->getSize().Z)))
    {
        this->z = z;
    }
}

void GameSpace::obj::setScale(float sx, float sy, float sz)
{
    if (gs->getSize().X >= sx && sx > (-1 * (gs->getSize().X)))
    {
        this->sx = sx;
    }
    if (gs->getSize().Y > sy && sy > (-1 * (gs->getSize().Y)))
    {
        this->sy = sy;
    }
    if (gs->getSize().Z > sz && sz > (-1 * (gs->getSize().Z)))
    {
        this->sz = sz;
    }
}

void GameSpace::obj::setRotation(float dx, float dy, float dz)
{
    this->dx = dx;
    this->dy = dy;
    this->dz = dz;
}