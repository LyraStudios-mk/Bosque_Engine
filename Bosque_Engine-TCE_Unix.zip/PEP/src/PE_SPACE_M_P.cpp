#include "PE.hpp"

void GameSpace::resize(float size_x, float size_y, float size_z)
{
    this->size_x = size_x;
    this->size_y = size_y;
    this->size_z = size_z;
}