#ifndef PE_HPP
#define PE_HPP

#include <algorithm>

class GameSpace
{
private:
    float size_x, size_y, size_z;

public:
    GameSpace(float size_x = 1000, float size_y = 1000, float size_z = 1000)
        : size_x(size_x), size_y(size_y), size_z(size_z) {}
    struct size
    {
        float X, Y, Z;
    };
    size getSize() const
    {
        return {size_x, size_y, size_z};
    }
    void resize(float size_x, float size_y, float size_z);
    class obj
    {
    private:
    GameSpace *gs;
        float x = 0, y = 0, z = 0;
        float dx = 0, dy = 0, dz = 0;
        float sx = 1, sy = 1, sz = 1;

    public:
        const bool is_colider;

        obj(GameSpace &gs, bool colider = false)
        : gs(&gs), is_colider(colider) {}

    // Copy constructor
    obj(const obj &other)
        : gs(other.gs), is_colider(other.is_colider), x(other.x), y(other.y), z(other.z),
          dx(other.dx), dy(other.dy), dz(other.dz),
          sx(other.sx), sy(other.sy), sz(other.sz),
          ColiderVerticesArray(other.ColiderVerticesArray) {}

    // Copy assignment operator
    obj &operator=(const obj &other)
    {
        if (this == &other)
            return *this;

        // Assign values
        gs = other.gs; // Copy the pointer
        x = other.x;
        y = other.y;
        z = other.z;
        dx = other.dx;
        dy = other.dy;
        dz = other.dz;
        sx = other.sx;
        sy = other.sy;
        sz = other.sz;
        ColiderVerticesArray = other.ColiderVerticesArray;

        return *this;
    }

        void setPosition(float x, float y, float z);
        void setScale(float sx, float sy, float sz);
        void setRotation(float dx, float dy, float dz);

        float X() const { return x; }

        float Y() const { return y; }

        float Z() const { return z; }

        float SX() const { return sx; }

        float SY() const { return sy; }

        float SZ() const { return sz; }

        float DX() const { return dx; }

        float DY() const { return dy; }

        float DZ() const { return dz; }
        struct ColiderVertices
        {
            float vertices[8][3];
        };
        ColiderVertices ColiderVerticesArray;
    };
};

bool collision(GameSpace::obj &obj1, GameSpace::obj &obj2);

#endif