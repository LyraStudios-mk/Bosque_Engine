#include "PE.hpp"

bool collision(GameSpace::obj &obj1, GameSpace::obj &obj2)
{
    if (!obj1.is_colider || !obj2.is_colider)
    {
        return false;
    }
    for (int axis = 0; axis < 3; ++axis)
    {
        float obj1_min = obj1.ColiderVerticesArray.vertices[0][axis];
        float obj1_max = obj1.ColiderVerticesArray.vertices[0][axis];
        for (int i = 1; i < 8; ++i)
        {
            obj1_min = std::min(obj1_min, obj1.ColiderVerticesArray.vertices[i][axis]);
            obj1_max = std::max(obj1_max, obj1.ColiderVerticesArray.vertices[i][axis]);
        }
        float obj2_min = obj2.ColiderVerticesArray.vertices[0][axis];
        float obj2_max = obj2.ColiderVerticesArray.vertices[0][axis];
        for (int i = 1; i < 8; ++i)
        {
            obj2_min = std::min(obj2_min, obj2.ColiderVerticesArray.vertices[i][axis]);
            obj2_max = std::max(obj2_max, obj2.ColiderVerticesArray.vertices[i][axis]);
        }
        if (obj1_max < obj2_min || obj2_max < obj1_min)
        {
            return false;
        }
    }
    return true;
}