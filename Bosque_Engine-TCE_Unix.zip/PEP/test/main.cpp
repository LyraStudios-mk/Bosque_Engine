#include <iostream>
#include <algorithm>
#include "../src/PEP.hpp"

int main()
{
    game_space gs(100, 100, 100);
    obj obj_(gs);
    std::cout << "X:" << obj_.X() << "Y:" << obj_.Y() << "Z:" << obj_.Z() << std::endl;
    std::cout << "Moving Object 10 units in all axis." << std::endl;
    obj_.vector3(obj_.X() + 10, obj_.Y() + 10, obj_.Z() + 10);
    std::cout << "X:" << obj_.X() << "Y:" << obj_.Y() << "Z:" << obj_.Z() << std::endl;
    std::cout << "Apliying Gravity of 0.1m/s^2. (Simulation at second 0 - 10)" << std::endl;
    float vel = 0;
    for (int i = 0; i < 10; i += 1)
    {
        gravity(obj_, vel, i, 0.1);
        std::cout << "Y:" << obj_.Y() << std::endl;
    }
    return 0;
}