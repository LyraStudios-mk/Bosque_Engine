# RootPhysics Engine - Physics Engine Pipeline (PEP)

The **RootPhysics Engine (RPE)** is a lightweight physics simulation engine designed to handle basic 3D object interactions, including gravity and collision detection. The **Physics Engine Pipeline (PEP)** is a modular system that processes the physics operations, ensuring realistic behaviors of objects in a 3D environment.

This repository contains the core header files for setting up and using basic physics operations in your own project.

## Features

- **Gravity Simulation**: Simulates gravity on objects based on their velocity and the time step.
- **Collision Detection**: Axis-aligned bounding box (AABB) collision detection between objects.
- **Resizable Game Space**: Define and resize a 3D space within which objects interact.
- **Object Movement**: Objects can move, resize, and participate in collision detection if enabled.

## Usage

Since this is a header-only library, you simply need to include the `pep.hpp` header file in your project.

### Getting Started

1. Place the `pep.hpp` file in an accessible folder within your project directory.

2. Include it in your source files where needed:
    ```cpp
    #include "path/to/pep.hpp"
    ```

3. Compile and run your program using any standard C++ compiler.

---

## File Descriptions

### `pep.hpp`

This is the primary header file containing the **Physics Engine Pipeline (PEP)** for RootPhysics Engine. It defines the following classes and functions:

#### Classes:

- **`game_space`**: Represents a 3D space where objects are placed. It has methods for resizing and querying the size of the space along the X, Y, and Z axes.
- **`obj`**: Represents an object in the 3D game space. This class includes methods for setting the object's position, resizing, and checking if the object is moving, still, or falling. Objects can also be designated as colliders to participate in collision detection.

#### Functions:

- **`gravity(obj &obj, float &velocity, float time_step, float gravity_c = 9.8f)`**: Applies gravity to an object based on its current velocity and the time step.
- **`collision(obj &obj1, obj &obj2)`**: Checks if two objects are colliding using axis-aligned bounding box (AABB) detection.

---

## Physics Operations

### Gravity

The gravity simulation applies a force to the object based on the gravitational constant and updates the object's position and velocity accordingly.

```cpp
float velocity = 0.0f; // Initial velocity
gravity(obj1, velocity, 0.1f); // Apply gravity for 0.1 seconds
```

### Collision Detection

Collision detection checks if the bounding boxes of two objects overlap along each axis. This is done using **Axis-Aligned Bounding Box (AABB)** collision detection.

```cpp
if (collision(obj1, obj2)) {
    std::cout << "Objects are colliding!" << std::endl;
} else {
    std::cout << "Objects are not colliding." << std::endl;
}
```

---

## Example Usage

Here's an example demonstrating how to create a game space, define objects, and apply gravity and collision detection:

```cpp
#include "pep.hpp"

int main() {
    // Create a game space with default dimensions
    game_space gs;

    // Create two objects in the game space
    obj obj1(gs, true); // Collider-enabled object
    obj obj2(gs, true); // Another collider-enabled object

    // Set object positions
    obj1.vector3(2.0f, 5.0f, 0.0f);
    obj2.vector3(2.0f, 5.1f, 0.0f);

    // Simulate gravity on obj1
    float velocity = 0.0f;
    gravity(obj1, velocity, 0.1f);  // Apply gravity over 0.1 seconds

    // Check for collision
    if (collision(obj1, obj2)) {
        std::cout << "Objects are colliding!" << std::endl;
    } else {
        std::cout << "Objects are not colliding." << std::endl;
    }

    return 0;
}
```

---

## Contributing

If you'd like to contribute to RootPhysics Engine, feel free to fork the repository, make your changes, and submit a pull request. We welcome improvements, bug fixes, and new feature additions.

---

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

---

## Acknowledgments

- The project is inspired by fundamental physics principles like gravity and collision detection.
- Built with C++ standard features such as classes, arrays, and functions for managing 3D objects and interactions.
