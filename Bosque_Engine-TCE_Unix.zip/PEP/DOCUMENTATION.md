## Documentation for `pep.hpp`

### Overview
The `pep.hpp` header file provides a framework for defining and manipulating objects in a 3D game space. It includes functionality for managing object positions, simulating gravity, resizing game spaces, and detecting collisions between objects.

---

### Classes

#### 1. **`game_space`**
A class representing a 3D bounded space for objects to exist within.

##### **Public Methods**:
- **`game_space(float size_x = 10, float size_y = 10, float size_z = 10)`**  
  Constructor to initialize the dimensions of the game space.
  - `size_x`, `size_y`, `size_z`: Dimensions of the game space along the X, Y, and Z axes.

- **`float getsize(int axis)`**  
  Returns the size of the game space along the specified axis.
  - `axis`: `0` for X-axis, `1` for Y-axis, and `2` for Z-axis.

- **`void resize(float size_x, float size_y, float size_z)`**  
  Resizes the game space dimensions.
  - `size_x`, `size_y`, `size_z`: New dimensions for the X, Y, and Z axes.

---

#### 2. **`obj`**
A class representing an object within the game space.

##### **Public Members**:
- **`const bool is_colider`**  
  Indicates if the object can participate in collision detection.
- **`bool is_still`**  
  Specifies if the object is stationary.
- **`bool is_moving`**  
  Specifies if the object is moving.
- **`bool is_falling`**  
  Specifies if the object is falling (affected by gravity).

##### **Public Methods**:
- **`obj(game_space &game_space, bool colider = false)`**  
  Constructor to initialize an object in a specified game space.
  - `game_space`: Reference to a `game_space` object defining the bounds.
  - `colider`: Boolean to enable or disable collision detection for the object.

- **`void vector3(float _x, float _y, float _z)`**  
  Sets the position of the object in 3D space, ensuring it remains within bounds.
  - `_x`, `_y`, `_z`: Coordinates for the object.

- **`float X()`**  
  Returns the current X-coordinate of the object.

- **`float Y()`**  
  Returns the current Y-coordinate of the object.

- **`float Z()`**  
  Returns the current Z-coordinate of the object.

- **`void resize(game_space &game_space)`**  
  Updates the object’s bounds based on the new game space dimensions.
  - `game_space`: Reference to a `game_space` object.

##### **Nested Struct**:
- **`struct box_colider_vertex`**  
  Represents the eight vertices of the bounding box for collision detection.
  - `vertex[8][3]`: Array to store coordinates of the bounding box vertices.

---

### Functions

#### 1. **`void gravity(obj &obj, float &velocity, float time_step, float gravity_c = 9.8f)`**
Simulates the effect of gravity on an object.

- **Parameters**:
  - `obj`: Reference to the object affected by gravity.
  - `velocity`: Reference to the current velocity of the object.
  - `time_step`: Time interval over which the gravity is applied.
  - `gravity_c`: Gravitational constant (default: 9.8 m/s²).

- **Behavior**:
  - Updates the `is_falling` status of the object.
  - Computes the new velocity and updates the object’s Y-coordinate accordingly.

---

#### 2. **`bool collision(obj &obj1, obj &obj2)`**
Checks if two objects are colliding based on their bounding box vertices.

- **Parameters**:
  - `obj1`, `obj2`: References to the objects being tested for collision.

- **Returns**:
  - `true` if the objects collide.
  - `false` otherwise.

- **Behavior**:
  - Performs axis-aligned bounding box (AABB) collision detection.
  - Iterates through all axes (X, Y, Z) and checks for overlap in the bounding box ranges.

---

### Usage Example

```cpp
#include "pep.hpp"

int main() {
    // Create a game space with default dimensions
    game_space gs;

    // Create two objects in the game space
    obj obj1(gs, true); // Collider-enabled object
    obj obj2(gs, true); // Another collider-enabled object

    // Set positions
    obj1.vector3(2.0f, 5.0f, 0.0f);
    obj2.vector3(2.0f, 5.1f, 0.0f);

    // Check for collision
    if (collision(obj1, obj2)) {
        std::cout << "Objects are colliding!" << std::endl;
    } else {
        std::cout << "Objects are not colliding." << std::endl;
    }

    return 0;
}
```

This code demonstrates creating a game space, adding objects, positioning them, and detecting collisions.