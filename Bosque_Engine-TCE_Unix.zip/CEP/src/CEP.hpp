#ifndef CEP_HPP
#define CEP_HPP

#include "GE.hpp"
#include "PE.hpp"

#endif