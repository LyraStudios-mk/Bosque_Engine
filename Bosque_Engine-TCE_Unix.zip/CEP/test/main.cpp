#include <iostream>
#include "../src/CEP.hpp"
#include <string>
#include <chrono>
#include <cstring>

sf::RenderWindow window;

float fov = 100, near = 22, far = 1500;

bool debug = false;
int show = 0;
bool gravity_ = false;
bool isConsole = false;
RenderBuffer buffer;
bool show_fps_var = false, show_cordinates = false, show_directions = false, show_scales = false, show_pivote = false;

/* Damm this code--------
const int commandsCount = 3;
const std::string COMMANDS_TOE[commandsCount] = {"show-fps", "show-run_time", "show-"};

void show_fps(std::string){}
void show_run_time(std::string){}

std::vector<void (*)(std::string)> commandsFunctions = {show_fps, show_run_time};
*/
int main(int argc, char **argv)
{
    // Setup game space and scene
    GameSpace gs(1000, 1000, 1000);
    std::vector<GameSpace::obj> objs;
    Scene sc;

    // Parsing arguments
    if (argc >= 2)
    {
        for (int i = 1; i < argc; ++i)
        {
            if (strcmp(argv[i], "-d") == 0)
            {
                debug = true;
            }
            else if (strcmp(argv[i], "--show-edges") == 0)
            {
                show = 1;
            }
            else if (strcmp(argv[i], "--attribute-gravity") == 0)
            {
                gravity_ = true;
            }
            else if (std::string file = argv[i]; file.find("t=") != -1)
            {
                std::string file_b = argv[i];
                file_b = file_b.substr(file_b.find("t=", 0) + 2, file_b.size());
                sf::Texture texture;
                texture.loadFromFile(file_b.c_str());
                if (sc.renderObjects.size() != 0)
                    sc.renderObjects[sc.renderObjects.size() - 1].texture = texture;
                else
                {
                    std::cerr << "CONTROL WARNING: Missing Model/Object" << std::endl;
                }
            }
            else
            {
                std::string file_a = argv[i];
                sc.renderObjects.emplace_back();
                read(file_a.c_str(), sc.renderObjects.back());
                objs.emplace_back(gs);
                sc.renderObjects.back().pivote.calculatePivote(sc.renderObjects.back());
            }
        }
    }
    else if (argc == 1)
    {
        objs.emplace_back(gs);
    }

    Camera cam;
    screen(800, 600, "TEST");

    sf::Font ft;
    ft.loadFromFile("arial.ttf");
    sf::Text tx;
    tx.setFont(ft);
    tx.setCharacterSize(20);
    tx.setFillColor(sf::Color::White);
    sf::Text tx2;
    tx2.setFont(ft);
    tx2.setCharacterSize(20);
    tx2.setFillColor(sf::Color::White);
    sf::Text tx3;
    tx3.setFont(ft);
    tx3.setCharacterSize(20);
    tx3.setFillColor(sf::Color::White);
    sf::Text tx5;
    tx5.setFont(ft);
    tx5.setCharacterSize(20);
    tx5.setFillColor(sf::Color::White);
    sf::Text tx4;
    tx4.setFont(ft);
    tx4.setCharacterSize(20);
    tx4.setFillColor(sf::Color::White);
    tx4.setPosition(sf::Vector2f(0, 20));

    std::string command;

    // Time tracking variables
    auto lastTime = std::chrono::high_resolution_clock::now();
    float deltaTime = 0.0f;
    int frameCount = 0;
    float fps = 0.0f;

    float velocity = 0.0f; // Initial velocity
    float gravity = 17.62f;

    int8_t keybind_d;
    unsigned int selection = 0;
    int steps = 10;

    while (window.isOpen())
    {
        // Start frame time measurement
        auto startTime = std::chrono::high_resolution_clock::now();

        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
            {
                window.close();
            }
            if (event.type == sf::Event::KeyPressed)
            {
                if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
                {
                    exit(0);
                }
                if (sf::Keyboard::isKeyPressed(sf::Keyboard::Slash) && debug)
                {
                    if (isConsole == false)
                        isConsole = true;
                    else if (isConsole == true)
                    {
                        isConsole = false;
                        tx4.setString("");
                    }
                }
                if (sf::Keyboard::isKeyPressed(sf::Keyboard::Enter))
                {
                    /*for(int iteration = 0; iteration < commandsCount; iteration++){
                        if(command.find(COMMANDS_TOE[commandsCount]) != -1){}
                    }*/
                    if (command == "/show-edges")
                    {
                        show = 1;
                    }
                    if (command == "/hide-all")
                    {
                        show = 0;
                    }
                    if (command == "/show-fps")
                    {
                        show_fps_var = true;
                    }
                    if (command == "/show-cordinates")
                    {
                        show_cordinates = true;
                    }
                    if (command == "/show-directions")
                    {
                        show_directions = true;
                    }
                    if (command == "/show-scales")
                    {
                        show_scales = true;
                    }
                    if (command == "/show-pivote")
                    {
                        show_pivote = true;
                    }
                    if (command == "/hide-fps")
                    {
                        show_fps_var = false;
                    }
                    if (command == "/hide-cordinates")
                    {
                        show_cordinates = false;
                    }
                    if (command == "/hide-directions")
                    {
                        show_directions = false;
                    }
                    if (command == "/hide-scales")
                    {
                        show_scales = false;
                    }
                    if (command == "/hide-pivote")
                    {
                        show_pivote = false;
                    }
                    if (command.find("/add-model=") != -1)
                    {
                        command = command.substr(command.find("=") + 1, command.size());
                        sc.renderObjects.push_back(Scene::RenderObject{}); // Construct directly in the vector
                        read(command.c_str(), sc.renderObjects.back());
                        objs.push_back(GameSpace::obj{gs}); // Similar for objs vector
                        sc.renderObjects.back().pivote.calculatePivote(sc.renderObjects.back());
                    }
                    if (command.find("/del-model") != -1)
                    {
                        if (sc.renderObjects.size() > 2)
                        {
                            sc.renderObjects.erase(sc.renderObjects.begin() + selection);
                            objs.erase(objs.begin() + selection);
                            selection--;
                        }
                    }
                    if (command.find("/add-texture=") != -1)
                    {
                        command = command.substr(command.find("=") + 1, command.size());
                        sf::Texture texture;
                        texture.loadFromFile(command.c_str());
                        sc.renderObjects[selection].texture = texture;
                    }
                    if (command.find("/set-steps=") != -1)
                    {
                        command = command.substr(command.find("=") + 1, command.size());
                        steps = std::stoi(command);
                    }

                    if (command.find("/set-far=") != -1)
                    {
                        command = command.substr(command.find("=") + 1, command.size());
                        far = std::stoi(command);
                    }

                    if (command.find("/set-near=") != -1)
                    {
                        command = command.substr(command.find("=") + 1, command.size());
                        near = std::stoi(command);
                    }

                    if (command.find("/set-fov=") != -1)
                    {
                        command = command.substr(command.find("=") + 1, command.size());
                        fov = std::stoi(command);
                    }
                    if (command == "/exit")
                    {
                        exit(0);
                    }
                    command = "";
                    isConsole = false;
                    tx4.setString("");
                }
                if (!isConsole)
                {
                    if (event.key.code == sf::Keyboard::A)
                    {
                        keybind_d = 0;
                    }
                    if (event.key.code == sf::Keyboard::D)
                    {
                        keybind_d = -1;
                    }
                    if (event.key.code == sf::Keyboard::W)
                    {
                        keybind_d = 1;
                    }
                    if (event.key.code == sf::Keyboard::S)
                    {
                        keybind_d = -2;
                    }
                    if (event.key.code == sf::Keyboard::Q)
                    {
                        keybind_d = 2;
                    }
                    if (event.key.code == sf::Keyboard::E)
                    {
                        keybind_d = -3;
                    }
                    if (event.key.code == sf::Keyboard::R)
                    {
                        switch (keybind_d)
                        {
                        case -3:
                            objs[selection].setRotation(objs[selection].DX(), objs[selection].DY(), objs[selection].DZ() - steps);
                            break;
                        case -2:
                            objs[selection].setRotation(objs[selection].DX(), objs[selection].DY() - steps, objs[selection].DZ());
                            break;
                        case -1:
                            objs[selection].setRotation(objs[selection].DX() - steps, objs[selection].DY(), objs[selection].DZ());
                            break;
                        case 0:
                            objs[selection].setRotation(objs[selection].DX() + steps, objs[selection].DY(), objs[selection].DZ());
                            break;
                        case 1:
                            objs[selection].setRotation(objs[selection].DX(), objs[selection].DY() + steps, objs[selection].DZ());
                            break;
                        case 2:
                            objs[selection].setRotation(objs[selection].DX(), objs[selection].DY(), objs[selection].DZ() + steps);
                            break;
                        }
                    }
                    if (event.key.code == sf::Keyboard::T)
                    {
                        switch (keybind_d)
                        {
                        case -3:
                            objs[selection].setPosition(objs[selection].X(), objs[selection].Y(), objs[selection].Z() - steps);
                            break;
                        case -2:
                            objs[selection].setPosition(objs[selection].X(), objs[selection].Y() - steps, objs[selection].Z());
                            break;
                        case -1:
                            objs[selection].setPosition(objs[selection].X() - steps, objs[selection].Y(), objs[selection].Z());
                            break;
                        case 0:
                            objs[selection].setPosition(objs[selection].X() + steps, objs[selection].Y(), objs[selection].Z());
                            break;
                        case 1:
                            objs[selection].setPosition(objs[selection].X(), objs[selection].Y() + steps, objs[selection].Z());
                            break;
                        case 2:
                            objs[selection].setPosition(objs[selection].X(), objs[selection].Y(), objs[selection].Z() + steps);
                            break;
                        }
                    }
                    if (event.key.code == sf::Keyboard::F)
                    {
                        switch (keybind_d)
                        {
                        case -3:
                            objs[selection].setScale(objs[selection].SX(), objs[selection].SY(), objs[selection].SZ() - steps);
                            break;
                        case -2:
                            objs[selection].setScale(objs[selection].SX(), objs[selection].SY() - steps, objs[selection].SZ());
                            break;
                        case -1:
                            objs[selection].setScale(objs[selection].SX() - steps, objs[selection].SY(), objs[selection].SZ());
                            break;
                        case 0:
                            objs[selection].setScale(objs[selection].SX() + steps, objs[selection].SY(), objs[selection].SZ());
                            break;
                        case 1:
                            objs[selection].setScale(objs[selection].SX(), objs[selection].SY() + steps, objs[selection].SZ());
                            break;
                        case 2:
                            objs[selection].setScale(objs[selection].SX(), objs[selection].SY(), objs[selection].SZ() + steps);
                            break;
                        }
                    }
                    if (event.key.code == sf::Keyboard::Up)
                    {
                        if (selection < objs.size() - 1)
                            selection++;
                    }
                    if (event.key.code == sf::Keyboard::Down)
                    {
                        if (selection > 0)
                            selection--;
                    }
                    if (event.key.code == sf::Keyboard::Tab)
                    {
                        if (debug == false)
                            debug = true;
                        else if (debug == true)
                            debug = false;
                    }
                }
            }
            if (event.type == sf::Event::TextEntered && isConsole)
            {
                if (event.text.unicode == 8) // Backspace
                {
                    if (!command.empty())
                        command.pop_back();
                }
                else if (event.text.unicode < 128) // ASCII characters
                {
                    command += static_cast<char>(event.text.unicode);
                }
                else if (event.text.unicode == 13 || event.text.unicode == 10) // ASCII character ENTER
                {
                    command += '\n';
                }
                tx4.setString(command);
            }
            else if (event.type == sf::Event::TextEntered && !isConsole)
            {
                if (event.text.unicode == 8) // Backspace
                {
                    continue;
                }
                else if (event.text.unicode < 128) // ASCII characters
                {
                    // std::cout << static_cast<char>(event.text.unicode) << '\n';
                }
            }
        }

        /*for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                objs[].ColiderVerticesArray.vertices[i][j] = sc.renderObjects[0].vertices[i][j];
                objs[].ColiderVerticesArray.vertices[i][j] = sc.renderObjects[1].vertices[i][j];
            }
        }
        if (!collision(obj_d, obj_h) && gravity_)
        {
            velocity -= gravity * deltaTime;                                                  // Apply gravity to velocity (acceleration due to gravity)
            obj_s.setPosition(obj_s.X(), obj_s.Y() + velocity * deltaTime * 2.0f, obj_s.Z()); // Update position based on velocity
        }
        */
        if (sc.renderObjects.size() > 0)
        {

            setPosition(objs[selection].X(), objs[selection].Y(), objs[selection].Z(), sc.renderObjects[selection]);
            setScale(objs[selection].SX(), objs[selection].SY(), objs[selection].SZ(), sc.renderObjects[selection]);
            setRotation(objs[selection].DX(), objs[selection].DY(), objs[selection].DZ(), sc.renderObjects[selection]);
            cam.setFarness(far);   // 1500
            cam.setNearness(near); // 200
            cam.project(fov, sc);  // 100

            tx2.setPosition(-sc.renderObjects[selection].objPosition.x + window.getSize().x / 2, -sc.renderObjects[selection].objPosition.y + window.getSize().y / 2);
            tx5.setPosition(-sc.renderObjects[selection].objPosition.x + window.getSize().x / 2, -sc.renderObjects[selection].objPosition.y + (window.getSize().y / 2) - 20);
            tx3.setPosition(-sc.renderObjects[selection].objPosition.x + window.getSize().x / 2, -sc.renderObjects[selection].objPosition.y + (window.getSize().y / 2) - 40);
            tx2.setString("(X: " + std::to_string(sc.renderObjects[selection].objPosition.x) + ", Y: " + std::to_string(sc.renderObjects[selection].objPosition.y) + ", Z: " + std::to_string(sc.renderObjects[selection].objPosition.z) + ")");
            tx5.setString("(SX: " + std::to_string(sc.renderObjects[selection].objPosition.sx) + ", SY: " + std::to_string(sc.renderObjects[selection].objPosition.sy) + ", SZ: " + std::to_string(sc.renderObjects[selection].objPosition.sz) + ")");
            tx3.setString("(DX: " + std::to_string(sc.renderObjects[selection].objPosition.dx) + ", DY: " + std::to_string(sc.renderObjects[selection].objPosition.dy) + ", DZ: " + std::to_string(sc.renderObjects[selection].objPosition.dz) + ")");
            sf::Vertex point(sf::Vector2f(sc.renderObjects[selection].objPosition.x + (sc.renderObjects[selection].pivote.pvx + window.getSize().x / 2), sc.renderObjects[selection].objPosition.y + (sc.renderObjects[selection].pivote.pvy + window.getSize().x / 2)), sf::Color::White);
            // std::cout << "PVX:" << sc.renderObjects[selection].pivote.pvx << " PVY:" << sc.renderObjects[selection].pivote.pvy << " PVZ:" << sc.renderObjects[selection].pivote.pvz << '\n';
            window.clear();

            if (!debug)
            {
                render_object(sc, buffer, cam);
                render_screen_d(sc, buffer);
            }
            else
            {
                if (show_fps_var)
                    window.draw(tx);
                if (show_cordinates)
                    window.draw(tx2);
                if (show_directions)
                    window.draw(tx3);
                if (show_scales)
                    window.draw(tx5);
                if (show_pivote)
                    window.draw(&point, 1, sf::Points);
                if (isConsole)
                    window.draw(tx4);
                switch (show)
                {
                case 0:
                    render_object(sc, buffer, cam);
                    break;
                case 1:
                    /*if (!collision(objs[], objs[]))
                    {*/
                    render_object_edge(sc, buffer, sf::Color::Red, selection);
                    /*}
                        else
                        {
                            render_object_edge(sc, buffer, sf::Color::Red);
                        }*/
                    break;
                }
                render_screen_d(sc, buffer, false);
            }
        }
        else
        {
            window.clear();
            if (debug)
            {

                if (show_fps_var)
                    window.draw(tx);
                if (isConsole)
                    window.draw(tx4);
            }
            window.display();
        }

        // End frame time measurement
        auto endTime = std::chrono::high_resolution_clock::now();
        std::chrono::duration<float> duration = endTime - startTime;
        deltaTime = duration.count();

        // Calculate FPS (Frames Per Second)
        frameCount++;
        auto elapsedTime = std::chrono::high_resolution_clock::now() - lastTime;
        if (std::chrono::duration<float>(elapsedTime).count() >= 1.0f)
        {
            fps = frameCount;
            frameCount = 0;
            lastTime = std::chrono::high_resolution_clock::now();
            tx.setString("FPS: " + std::to_string(static_cast<int>(fps)));
        }
    }

    return EXIT_SUCCESS;
}
