### License Information

The Graphics Engine Pipeline (GEP) for Leaft Engine is open-source and distributed under the [MIT License](https://opensource.org/licenses/MIT). You are free to use, modify, and distribute the software, provided that the following conditions are met:

1. **Copyright Notice**: Retain the copyright notice and the list of conditions in all copies or substantial portions of the software.
   
2. **No Warranty**: The software is provided "as is", without warranty of any kind, express or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose, and non-infringement.

### License Summary

- **Permissions**: You may use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the software.
- **Conditions**: You must include the copyright notice and a copy of the license in any distributed software.
- **Limitations**: There is no warranty provided with this software.

This license ensures that you have the flexibility to adapt the GEP for Leaft Engine to your needs, while keeping the software free and accessible for others.