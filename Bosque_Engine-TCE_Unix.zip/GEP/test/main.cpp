#include <string>
#include "../src/GEP.hpp"

sf::RenderWindow window;

int main(int argc, char **argv)
{
    obj obj_;
    if(argc < 2) return 1;
    std::string file_a = argv[1];
    std::string file_b = file_a + "_dt";
    read(file_a.c_str(), file_b.c_str(), obj_);
    camera(120.0f,obj_);
    screen(800,600,"TEST");
    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
        }
        render_object(obj_);
    }

    return EXIT_SUCCESS;
}