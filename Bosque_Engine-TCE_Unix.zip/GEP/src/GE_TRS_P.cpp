#include "GE.hpp"

/**
 * @brief addPosition moves a render object by axis steps.
 *
 * @param float deltaX, float deltaY, float deltaZ, Scene::RenderObject &obj
 */
void addPosition(float deltaX, float deltaY, float deltaZ, Scene::RenderObject &obj)
{
    for (int i = 0; i < obj.vertexCount; ++i)
    {
        obj.vertices[i][0] -= deltaX;
        obj.vertices[i][1] -= deltaY;
        obj.vertices[i][2] -= deltaZ;
    }
}

/**
 * @brief setPosition move a render object to the specified axis position.
 *
 * @param float x, float y, float z, Scene::RenderObject &obj
 */
//
void setPosition(float x, float y, float z, Scene::RenderObject &obj)
{
    if (obj.objPosition.x == x && obj.objPosition.y == y && obj.objPosition.z == z)
    {
        return;
    }
    float deltaX = x - obj.objPosition.x;
    float deltaY = y - obj.objPosition.y;
    float deltaZ = z - obj.objPosition.z;
    for (int i = 0; i < obj.vertexCount; ++i)
    {
        obj.vertices[i][0] -= deltaX;
        obj.vertices[i][1] -= deltaY;
        obj.vertices[i][2] -= deltaZ;
    }
    obj.objPosition.x = x;
    obj.objPosition.y = y;
    obj.objPosition.z = z;
}

/**
 * @brief addPosition scale a render object by axis steps.
 *
 * @param float deltaX, float deltaY, float deltaZ, Scene::RenderObject &obj
 */
void addScale(float deltaSX, float deltaSY, float deltaSZ, Scene::RenderObject &obj)
{
    for (int i = 0; i < obj.vertexCount; ++i)
    {
        obj.vertices[i][0] *= deltaSX;
        obj.vertices[i][1] *= deltaSY;
        obj.vertices[i][2] *= deltaSZ;
    }
}

/**
 * @brief setScale scale a render object to the specified axis size.
 *
 * @param float x, float y, float z, Scene::RenderObject &obj
 */
void setScale(float sx, float sy, float sz, Scene::RenderObject &obj)
{
    if (obj.objPosition.sx == sx && obj.objPosition.sy == sy && obj.objPosition.sz == sz)
    {
        return;
    }

    // Calculate the scale factor for each axis
    float deltaSX = sx / obj.objPosition.sx;
    float deltaSY = sy / obj.objPosition.sy;
    float deltaSZ = sz / obj.objPosition.sz;

    // Apply scaling to vertices relative to the pivot
    for (int i = 0; i < obj.vertexCount; ++i)
    {
        obj.vertices[i][0] = obj.pivote.pvx + (obj.vertices[i][0] - obj.pivote.pvx) * deltaSX;
        obj.vertices[i][1] = obj.pivote.pvy + (obj.vertices[i][1] - obj.pivote.pvy) * deltaSY;
        obj.vertices[i][2] = obj.pivote.pvz + (obj.vertices[i][2] - obj.pivote.pvz) * deltaSZ;
    }

    // Update scale values
    obj.objPosition.sx = sx;
    obj.objPosition.sy = sy;
    obj.objPosition.sz = sz;
}

/**
 * @brief addRotation rotates a render object by axis steps.
 *
 * @param float deltaDX, float deltaDY, float deltaDZ, Scene::RenderObject &obj
 */
void addRotation(float deltaDX, float deltaDY, float deltaDZ, Scene::RenderObject &obj)
{
    obj.objPosition.dx += deltaDX;
    obj.objPosition.dy += deltaDY;
    obj.objPosition.dz += deltaDZ;
}

/**
 * @brief setRotation rotates a render object to the specified axis direction.
 *
 * @param float dx, float dy, float dz, Scene::RenderObject &obj
 */
void setRotation(float dx, float dy, float dz, Scene::RenderObject &obj)
{
    obj.objPosition.dx = dx;
    obj.objPosition.dy = dy;
    obj.objPosition.dz = dz;
}

/**
 * @brief setRotation rotates a render object to the specified axis direction.
 *
 * @param float dx, float dy, float dz, Scene::RenderObject &obj
 */
void Camera::setRotation_Internal(Scene::RenderObject &obj)
{
    float radians;
    float cosAngle;
    float sinAngle;
    float x;
    float y;
    float z;
    for (int axis = 0; axis < 3; axis += 1)
    {
        switch (axis)
        {
        case 0:
            radians = obj.objPosition.dx * (3.14159265359 / 180.0f);
            break;
        case 1:
            radians = obj.objPosition.dy * (3.14159265359 / 180.0f);
            break;
        case 2:
            radians = obj.objPosition.dz * (3.14159265359 / 180.0f);
            break;
        }
        cosAngle = cos(radians);
        sinAngle = sin(radians);

        for (int i = 0; i < obj.vertexCount; ++i)
        {
            switch (axis)
            {
            case 0:
                x = obj.vertices[i][0] - (obj.pivote.pvx - obj.objPosition.x);
                y = obj.vertices[i][1] - (obj.pivote.pvy - obj.objPosition.y);
                z = obj.vertices[i][2] - (obj.pivote.pvz - obj.objPosition.z);
                obj.rotatedVertices[i][0] = (x) + (obj.pivote.pvx - obj.objPosition.x);
                obj.rotatedVertices[i][1] = ((y * cosAngle) - (z * sinAngle)) + (obj.pivote.pvy - obj.objPosition.y);
                obj.rotatedVertices[i][2] = ((y * sinAngle) + (z * cosAngle)) + (obj.pivote.pvz - obj.objPosition.z);
                break;
            case 1:
                x = obj.rotatedVertices[i][0] - (obj.pivote.pvx - obj.objPosition.x);
                y = obj.rotatedVertices[i][1] - (obj.pivote.pvy - obj.objPosition.y);
                z = obj.rotatedVertices[i][2] - (obj.pivote.pvz - obj.objPosition.z);
                obj.rotatedVertices[i][0] = ((x * cosAngle) + (z * sinAngle)) + (obj.pivote.pvx - obj.objPosition.x);
                obj.rotatedVertices[i][1] = (y) + (obj.pivote.pvy - obj.objPosition.y);
                obj.rotatedVertices[i][2] = ((-x * sinAngle) + (z * cosAngle)) + (obj.pivote.pvz - obj.objPosition.z);
                break;
            case 2:
                x = obj.rotatedVertices[i][0] - (obj.pivote.pvx - obj.objPosition.x);
                y = obj.rotatedVertices[i][1] - (obj.pivote.pvy - obj.objPosition.y);
                z = obj.rotatedVertices[i][2] - (obj.pivote.pvz - obj.objPosition.z);
                obj.rotatedVertices[i][0] = ((x * cosAngle) - (y * sinAngle)) + (obj.pivote.pvx - obj.objPosition.x);
                obj.rotatedVertices[i][1] = ((x * sinAngle) + (y * cosAngle)) + (obj.pivote.pvy - obj.objPosition.y);
                obj.rotatedVertices[i][2] = (z) + (obj.pivote.pvz - obj.objPosition.z);
                break;
            }
        }
    }
}

/**
 * @brief X, Y, Z, DX, DY, DZ are return functions, or getter functions that return what they claim to.
 *
 * @param Scene::RenderObject &obj
 */
float X(Scene::RenderObject &obj)
{
    return obj.objPosition.x;
}

float Y(Scene::RenderObject &obj)
{
    return obj.objPosition.y;
}

float Z(Scene::RenderObject &obj)
{
    return obj.objPosition.z;
}

float SX(Scene::RenderObject &obj)
{
    return obj.objPosition.sx;
}

float SY(Scene::RenderObject &obj)
{
    return obj.objPosition.sy;
}

float SZ(Scene::RenderObject &obj)
{
    return obj.objPosition.sz;
}

float DX(Scene::RenderObject &obj)
{
    return obj.objPosition.dx;
}

float DY(Scene::RenderObject &obj)
{
    return obj.objPosition.dy;
}

float DZ(Scene::RenderObject &obj)
{
    return obj.objPosition.dz;
}

/**
 * @brief  Camera::setposition move a camera to the specified axis position.
 *
 * @param float x, float y, float z
 */
void Camera::setPosition(float x, float y, float z)
{
    this->x = x;
    this->y = y;
    this->z = z;
    return;
}

/**
 * @brief Camera::setRotation rotates a camera to the specified axis direction.
 *
 * @param float dx, float dy, float dz
 */
void Camera::setRotation(float dx, float dy, float dz)
{
    this->dx = dx;
    this->dy = dy;
    this->dz = dz;
    return;
}