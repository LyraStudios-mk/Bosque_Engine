#include "GE.hpp"

/**
 * @brief Camera::project function transform the 3D cordinates of the object, and transform them into 2D screen renderizable cordinates.
 *
 * @param float fov, Scene &sc
 */
void Camera::project(float fov, Scene &sc)
{
    float max = std::numeric_limits<float>::lowest();
    for (int j = 0; j < sc.renderObjects.size(); j += 1)
    {
        if(sc.renderObjects[j].forceNoRender){
            continue;
        }
        setRotation_Internal(sc.renderObjects[j]);
        for (int i = 0; i < sc.renderObjects[j].vertexCount; ++i)
        {
            float v_x = sc.renderObjects[j].rotatedVertices[i][0] + x;
            float v_y = sc.renderObjects[j].rotatedVertices[i][1] + y;
            float v_z = sc.renderObjects[j].rotatedVertices[i][2] + z + 10;
            for (int p = 0; p < sc.renderObjects[j].vertexCount; p += 1)
            {
                max = std::max(max, sc.renderObjects[j].rotatedVertices[p][2] + z);
            }
            //
            if (max > far || max < near)
            {
                sc.renderObjects[j].stopRender = true;
                return;
            }
            sc.renderObjects[j].stopRender = false;

            float projectedX = (v_x * fov) / v_z;
            float projectedY = (v_y * fov) / v_z;

            sc.renderObjects[j].projectedVertices[i][0] = (projectedX + ((window.getSize().x) / 2));
            sc.renderObjects[j].projectedVertices[i][1] = (projectedY + ((window.getSize().y) / 2));
        }
    }
}

/**
 * @brief render_object takes a projected data from an object and creates the respective frame on screen, then stores it into a buffer.
 *
 * @param Sceen &sc, RenderBuffer &bf
 */
void render_object(Scene &sc, RenderBuffer &bf, Camera &cm)
{
    bf.renderElements.resize(sc.renderObjects.size());

    for (int j = 0; j < sc.renderObjects.size(); j += 1)
    {
        if (sc.renderObjects[j].stopRender || sc.renderObjects[j].forceNoRender)
        {
            continue;
        }
        sf::VertexArray faces(sf::Triangles);

        for (int i = 0; i < sc.renderObjects[j].faceCount; ++i)
        {
            int v1 = sc.renderObjects[j].faces[i][0];
            int v2 = sc.renderObjects[j].faces[i][1];
            int v3 = sc.renderObjects[j].faces[i][2];

            sf::Vector2f pos1(sc.renderObjects[j].projectedVertices[v1][0], sc.renderObjects[j].projectedVertices[v1][1]);
            sf::Vector2f pos2(sc.renderObjects[j].projectedVertices[v2][0], sc.renderObjects[j].projectedVertices[v2][1]);
            sf::Vector2f pos3(sc.renderObjects[j].projectedVertices[v3][0], sc.renderObjects[j].projectedVertices[v3][1]);

            sf::Vector2f uv1(sc.renderObjects[j].uvs[v1][0], sc.renderObjects[j].uvs[v1][1]);
            sf::Vector2f uv2(sc.renderObjects[j].uvs[v2][0], sc.renderObjects[j].uvs[v2][1]);
            sf::Vector2f uv3(sc.renderObjects[j].uvs[v3][0], sc.renderObjects[j].uvs[v3][1]);

            faces.append(sf::Vertex(pos1, sf::Color::White, uv1));
            faces.append(sf::Vertex(pos2, sf::Color::White, uv2));
            faces.append(sf::Vertex(pos3, sf::Color::White, uv3));
        }
        bf.renderElements[j] = faces;
    }
}

///////////////////////////////////////////////
///////////////DEBUG TOOLS/////////////////////
///////////////////////////////////////////////

void render_object_edge(Scene &sc, RenderBuffer &bf, sf::Color color, int index_tr)
{
    bf.renderElements.resize((sc.renderObjects.size()));
    for (int j = 0; j < sc.renderObjects.size(); j += 1)
    {
        sf::VertexArray vertice(sf::Lines, 0);
        vertice.clear();
        for (int i = 0; i < sc.renderObjects[j].edgeCount; ++i)
        {
            int v1 = sc.renderObjects[j].edges[i][0];
            int v2 = sc.renderObjects[j].edges[i][1];
            if (index_tr == j)
            {
                vertice.append(sf::Vertex(sf::Vector2f(sc.renderObjects[j].projectedVertices[v1][0], sc.renderObjects[j].projectedVertices[v1][1]), color));
                vertice.append(sf::Vertex(sf::Vector2f(sc.renderObjects[j].projectedVertices[v2][0], sc.renderObjects[j].projectedVertices[v2][1]), color));
            }
            else
            {
                vertice.append(sf::Vertex(sf::Vector2f(sc.renderObjects[j].projectedVertices[v1][0], sc.renderObjects[j].projectedVertices[v1][1]), sf::Color::White));
                vertice.append(sf::Vertex(sf::Vector2f(sc.renderObjects[j].projectedVertices[v2][0], sc.renderObjects[j].projectedVertices[v2][1]), sf::Color::White));
            }
        }
        bf.renderElements[j] = vertice;
    }
}