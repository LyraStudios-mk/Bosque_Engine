#ifndef GE_HPP
#define GE_HPP

#include <SFML/Graphics.hpp>
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <cmath>

extern sf::RenderWindow window;

struct Scene
{
    // stores object data
    struct RenderObject
    {
        ////////////////////////
        ///////////DT///////////
        ////////////////////////
        // The day where everything went donw, it was when i began to use pointers.
        // stores the texture data
        sf::Texture texture;
        sf::Shader *shader;
        // stores the position and direction data
        struct Position
        {
            // position axis
            float x = 0.0f;
            float y = 0.0f;
            float z = 0.0f;
            // direction axis
            float dx = 0.0f;
            float dy = 0.0f;
            float dz = 0.0f;
            // scale axis
            float sx = 1.0f;
            float sy = 1.0f;
            float sz = 1.0f;
        };
        Position objPosition;

        // object model data count
        int vertexCount = 0;
        int edgeCount = 0;
        int faceCount = 0;
        int uvCount = 0;
        int normalCount = 0;

        bool stopRender = false;
        bool forceNoRender = false;
        bool renderWithShaders = false;

        ////////////////////////
        ///////////MD///////////
        ////////////////////////

        // object model data
        std::vector<std::vector<float>> vertices;
        std::vector<std::vector<int>> edges;
        std::vector<std::vector<int>> faces;
        std::vector<std::vector<float>> uvs;
        std::vector<std::vector<float>> normals;

        std::vector<std::vector<float>> rotatedVertices;
        std::vector<std::vector<float>> projectedVertices;

        struct pivot
        {
            float pvx = 0, pvy = 0, pvz = 0;

            void calculatePivote(RenderObject &rob)
            {
                float max = std::numeric_limits<float>::lowest();
                float min = std::numeric_limits<float>::max();
                for (int o = 0; o < 3; o++)
                {
                    for (int p = 0; p < rob.vertexCount; p += 1)
                    {
                        max = std::max(max, rob.vertices[p][o]);
                        min = std::min(min, rob.vertices[p][o]);
                    }
                    if (o == 0)
                        pvx = (max + min) / 2;
                    if (o == 1)
                        pvy = (max + min) / 2;
                    if (o == 2)
                        pvz = (max + min) / 2;
                }
            }
        };

        pivot pivote;

        ~RenderObject()
        {
            delete shader;
        }
    };
    // stores all objects in scene
    std::vector<RenderObject> renderObjects;
};

struct RenderBuffer
{
    // stores all objects in scene ready to display
    std::vector<sf::VertexArray> renderElements;
};

///////////////////////////////////////
//////////////TRS PIPE/////////////////
///////////////////////////////////////

// add or set new cordinates in position and direction for an object
void addPosition(float deltaX, float deltaY, float deltaZ, Scene::RenderObject &obj);
void setPosition(float x, float y, float z, Scene::RenderObject &obj);
void addScale(float deltaSX, float deltaSY, float deltaSZ, Scene::RenderObject &obj);
void setScale(float sx, float sy, float sz, Scene::RenderObject &obj);
void addRotation(float deltaDX, float deltaDY, float deltaDZ, Scene::RenderObject &obj);
void setRotation(float dx, float dy, float dz, Scene::RenderObject &obj);

// return the object position
float X(Scene::RenderObject &obj);
float Y(Scene::RenderObject &obj);
float Z(Scene::RenderObject &obj);
// return the object direction
float SX(Scene::RenderObject &obj);
float SY(Scene::RenderObject &obj);
float SZ(Scene::RenderObject &obj);
// return the object direction
float DX(Scene::RenderObject &obj);
float DY(Scene::RenderObject &obj);
float DZ(Scene::RenderObject &obj);

///////////////////////////////////////
//////////////RENDER DEVICE////////////
///////////////////////////////////////

class Camera
{
private:
    float x = 0, y = 0, z = 0;
    float dx = 0, dy = 0, dz = 0;

    void setRotation_Internal(Scene::RenderObject &obj);

public:
    float far = 0, near = 0;
    // transform the 3D of the object into screen drawable 2D positions
    void
    project(float fov, Scene &sc);
    // add or set new cordinates in position and direction for a camera
    void setPosition(float x, float y, float z);
    void setRotation(float dx, float dy, float dz);
    // set the farness or nearness to a specified value.
    void setFarness(float far)
    {
        this->far = far;
    }
    void setNearness(float near)
    {
        this->near = near;
    }
    float X() const { return x; }
    float Y() const { return y; }
    float Z() const { return z; }
    float DX() const { return dx; }
    float DY() const { return dy; }
    float DZ() const { return dz; }
};
// convert render data into the final image that will be sent to screen
void render_object(Scene &sc, RenderBuffer &bf, Camera &cm);
void render_object_edge(Scene &sc, RenderBuffer &bf, sf::Color color, int index_tr = -1);

///////////////////////////////////////
//////////////IO PIPE//////////////////
///////////////////////////////////////

// read .col files and extract the model data
void read(const char fileNameExt[], Scene::RenderObject &obj);
// creates an instance of screen
void screen(int width, int height, char title[]);
// aplies the rendered images into the screen
void render_screen(Scene &sc, RenderBuffer &bf);
void render_screen_d(Scene &sc, RenderBuffer &bf, bool renderTexture = true);

#endif
/*
try
{
    throw std::ios_base::failure("");
}
catch (const std::ios_base::failure &e)
{
    std::cerr << " Error: " << e.what() << std::endl;
}
catch (...)
{
    std::cerr << " Error: Unknow Error"<< std::endl;
}
*/