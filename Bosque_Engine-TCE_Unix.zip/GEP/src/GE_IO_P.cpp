#include "GE.hpp"

/////////////////////////////////////////////////////////////////////////
//////////////////////////INPUT/////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////

/**
 * @brief read takes the input from the file, which must be a .col extention file, and stores in the object, the data extracted.
 *
 * @param const char fileNameExt, Scene::RenderObject &obj
 */
void read(const char fileNameExt[], Scene::RenderObject &obj)
{
    std::ifstream file(fileNameExt);
    try
    {
        if (!file)
        {
            throw std::ios_base::failure("File Not Found");
        }

        //
    }
    catch (const std::ios_base::failure &e)
    {
        std::cerr << "IO Error: " << e.what() << std::endl;
        std::exit(1);
    }
    catch (...)
    {
        std::cerr << "IO Error: Unknow Error" << std::endl;
        std::exit(1);
    }
    std::string line;
    int iteration_v = 0, iteration_e = 0, iteration_f = 0, iteration_u = 0, iteration_n = 0;
    bool reading_v = false;
    bool reading_e = false;
    bool reading_f = false;
    bool reading_u = false;
    bool reading_n = false;
    bool reading_vr = false;
    bool reading_vc = false;
    bool reading_ec = false;
    bool reading_fc = false;
    bool reading_uc = false;
    bool reading_nc = false;
    int errorCol = 0;
    std::string missing = "dt,vc,ec,fc,uc,nc";
    while (std::getline(file, line))
    {
        if (line.find('#') != -1)
            line = line.substr(0, line.find('#'));
        if (line.find('\r') != -1)
            line = line.substr(0, line.find('\r'));

        if (line.find(">>>dt<<<", 0) != -1)
        {
            reading_vr = true;
            if (missing.find("dt") != std::string::npos)
                missing.erase(missing.find("dt"), 3);
            errorCol += 1;
            continue;
        }
        if (line.find(">>>md<<<", 0) != -1)
        {
            break;
        }
        if (reading_vr)
        {
            if (line.find("vc", 0) != -1)
            {
                reading_vc = true;
                errorCol += 1;
                if (missing.find("vc") != std::string::npos)
                    missing.erase(missing.find("vc"), 3);
                continue;
            }
            if (line.find("ec", 0) != -1)
            {
                reading_ec = true;
                errorCol += 1;
                if (missing.find("ec") != std::string::npos)
                    missing.erase(missing.find("ec"), 3);
                continue;
            }
            if (line.find("fc", 0) != -1)
            {
                reading_fc = true;
                errorCol += 1;
                if (missing.find("fc") != std::string::npos)
                    missing.erase(missing.find("fc"), 3);
                continue;
            }
            if (line.find("uc", 0) != -1)
            {
                reading_uc = true;
                errorCol += 1;
                if (missing.find("uc") != std::string::npos)
                    missing.erase(missing.find("uc"), 3);
                continue;
            }
            if (line.find("nc", 0) != -1)
            {
                reading_nc = true;
                errorCol += 1;
                if (missing.find("nc") != std::string::npos)
                    missing.erase(missing.find("nc"), 3);
                continue;
            }

            if (reading_vc)
            {
                obj.vertexCount = std::stoi(line);
                reading_vc = false;
            }
            if (reading_ec)
            {
                obj.edgeCount = std::stoi(line);
                reading_ec = false;
            }
            if (reading_fc)
            {
                obj.faceCount = std::stoi(line);
                reading_fc = false;
            }
            if (reading_uc)
            {
                obj.uvCount = std::stoi(line);
                reading_uc = false;
            }
            if (reading_nc)
            {
                obj.normalCount = std::stoi(line);
                reading_nc = false;
            }
        }
    }
    if (errorCol < 6)
    {
        std::cerr << "IO ERROR: Missing critical identifiers: " << missing << std::endl;
        std::exit(1);
    }

    obj.vertices.resize(obj.vertexCount, std::vector<float>(3));
    obj.edges.resize(obj.edgeCount, std::vector<int>(2));
    obj.faces.resize(obj.faceCount, std::vector<int>(3));
    obj.uvs.resize(obj.uvCount, std::vector<float>(2));
    obj.normals.resize(obj.normalCount, std::vector<float>(2));
    obj.rotatedVertices.resize(obj.vertexCount, std::vector<float>(3));
    obj.projectedVertices.resize(obj.vertexCount, std::vector<float>(2));

    while (std::getline(file, line))
    {
        if (line.find('#') != -1)
            line = line.substr(0, line.find('#'));
        if (line.find('\r') != -1)
            line = line.substr(0, line.find('\r'));

        if (line.find('v', 0) != -1)
        {
            reading_v = true;
            continue;
        }
        if (line.find('e', 0) != -1)
        {
            reading_e = true;
            continue;
        }
        if (line.find('f', 0) != -1)
        {
            reading_f = true;
            continue;
        }
        if (line.find('u', 0) != -1)
        {
            reading_u = true;
            continue;
        }
        if (line.find('n', 0) != -1)
        {
            reading_n = true;
            continue;
        }

        if (reading_v)
        {
            if (line.find("<v?", 0) != -1)
            {
                if (iteration_v != obj.vertexCount)
                {
                    std::cerr << "IO ERROR: Data Mismach" << std::endl;
                    exit(1);
                }
                reading_v = false;
                continue;
            }
            float x, y, z;
            std::istringstream iss(line);
            if (iss >> x >> y >> z)
            {
                obj.vertices[iteration_v][0] = x;
                obj.vertices[iteration_v][1] = y;
                obj.vertices[iteration_v][2] = z;
                iteration_v++;
            }
            if (obj.vertexCount == iteration_v)
                reading_v = false;
            continue;
        }
        else if (reading_e)
        {
            if (line.find("<e?", 0) != -1)
            {
                if (iteration_e != obj.edgeCount)
                {
                    std::cerr << "IO ERROR: Data Mismach" << std::endl;
                    exit(1);
                }
                reading_e = false;
                continue;
            }
            int v1, v2;
            std::istringstream iss(line);
            if (iss >> v1 >> v2)
            {
                obj.edges[iteration_e][0] = v1;
                obj.edges[iteration_e][1] = v2;
                iteration_e++;
            }
            if (obj.edgeCount == iteration_e)
                reading_e = false;
            continue;
        }
        else if (reading_f)
        {
            if (line.find("<f?", 0) != -1)
            {
                if (iteration_f != obj.faceCount)
                {
                    std::cerr << "IO ERROR: Data Mismach" << std::endl;
                    exit(1);
                }
                reading_f = false;
                continue;
            }
            int v1, v2, v3;
            std::istringstream iss(line);
            if (iss >> v1 >> v2 >> v3)
            {
                obj.faces[iteration_f][0] = v1;
                obj.faces[iteration_f][1] = v2;
                obj.faces[iteration_f][2] = v3;
                iteration_f++;
            }
            if (obj.faceCount == iteration_f)
                reading_f = false;
            continue;
        }
        else if (reading_u)
        {
            if (line.find("<u?", 0) != -1)
            {
                if (iteration_u != obj.uvCount)
                {
                    std::cerr << "IO ERROR: Data Mismach" << std::endl;
                    exit(1);
                }
                reading_u = false;
                continue;
            }
            float v1, v2;
            std::istringstream iss(line);
            if (iss >> v1 >> v2)
            {
                obj.uvs[iteration_u][0] = v1;
                obj.uvs[iteration_u][1] = v2;
                iteration_u++;
            }
            if (obj.uvCount == iteration_u)
                reading_u = false;
            continue;
        }
        else if (reading_n)
        {
            if (line.find("<n?", 0) != -1)
            {
                if (iteration_n != obj.normalCount)
                {
                    std::cerr << "IO ERROR: Data Mismach" << std::endl;
                    exit(1);
                }
                reading_n = false;
                continue;
            }
            float v1, v2;
            std::istringstream iss(line);
            if (iss >> v1 >> v2)
            {
                obj.normals[iteration_n][0] = v1;
                obj.normals[iteration_n][1] = v2;
                iteration_n++;
            }
            if (obj.normalCount == iteration_n)
                reading_n = false;
            continue;
        }
    }

    file.close();
}

/////////////////////////////////////////////////////////////////////////
//////////////////////////OUTPUT/////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////

/**
 * @brief screen creates a screen instance.
 *
 * @param int width, int height, char title[]
 */
void screen(int width, int height, char title[])
{
    window.create(sf::VideoMode(width, height), title);
}

/**
 * @brief render_screen draw into the screen all the elements stored in the buffer, and aplies textures.
 *
 * @param Scene &sc, RenderBuffer &bf
 */
void render_screen(Scene &sc, RenderBuffer &bf)
{
    for (int i = 0; i < bf.renderElements.size(); i += 1)
    {
        for (int j = 0; j < sc.renderObjects.size(); j += 1)
        {
            if (!sc.renderObjects[j].stopRender && !sc.renderObjects[j].forceNoRender)
            {
                if (sc.renderObjects[j].renderWithShaders)
                {
                    window.draw(bf.renderElements[i], sc.renderObjects[j].shader);
                }
                else
                    window.draw(bf.renderElements[i], &sc.renderObjects[j].texture);
            }
        }
    }
    window.display();
}

//////////////////////////////
//////////DEBUGING////////////
//////////////////////////////

void render_screen_d(Scene &sc, RenderBuffer &bf, bool renderTexture)
{
    for (int i = 0; i < bf.renderElements.size(); i += 1)
    {
        for (int j = 0; j < sc.renderObjects.size(); j += 1)
        {
            if (!sc.renderObjects[j].stopRender && !sc.renderObjects[j].forceNoRender)
            {
                if (renderTexture)
                    window.draw(bf.renderElements[i], &sc.renderObjects[j].texture);
                else
                    window.draw(bf.renderElements[i]);
            }
        }
    }
    window.display();
}