### GEP (Graphics Engine Pipeline) Documentation

#### Overview

The Graphics Engine Pipeline (GEP) provides a set of functions for managing 3D objects, camera transformations, and rendering to the screen using the SFML (Simple and Fast Multimedia Library). This documentation explains how to use the various functions provided by GEP and gives an example of how to set up a basic program that uses it.

---

### **Header File: `GEP.hpp`**

The header file includes necessary declarations for functions and structures used in the engine.

#### **Structures**

1. **`obj`**:
   - Defines a 3D object with vertices and edges.
   - **Members**:
     - `vertex_count`: Total number of vertices.
     - `edge_count`: Total number of edges.
     - `vertex`: A 2D vector storing the 3D coordinates of each vertex.
     - `edges`: A 2D vector storing the edges, where each edge is defined by the indices of the vertices it connects.

#### **Functions**

1. **`move(int dx, int dy, int dz, obj& obj_)`**:
   - Moves the object by a specified distance along the x, y, and z axes.
   - **Parameters**:
     - `dx`, `dy`, `dz`: The offsets for each axis.
     - `obj_`: The object to be moved.
   
2. **`rotate(int degrees, int axis, obj& obj_)`**:
   - Rotates the object around the specified axis by the given number of degrees.
   - **Parameters**:
     - `degrees`: The number of degrees to rotate the object.
     - `axis`: The axis of rotation (0 = x, 1 = y, 2 = z).
     - `obj_`: The object to be rotated.

3. **`camera(float fov, obj& obj_)`**:
   - Adjusts the camera's field of view (FOV) for the object.
   - **Parameters**:
     - `fov`: The field of view in degrees (e.g., 120.0f).
     - `obj_`: The object whose camera perspective needs adjustment.

4. **`read(const char file_name[], const char file_name_[], obj& obj_)`**:
   - Reads the object data from the specified files.
   - **Parameters**:
     - `file_name`: The path to the file containing vertex data.
     - `file_name_`: The path to the file containing edge data.
     - `obj_`: The object to which the data will be read and loaded.

5. **`screen(int size_x, int size_y, char tittle[])`**:
   - Initializes the SFML window for rendering the objects.
   - **Parameters**:
     - `size_x`: The width of the window.
     - `size_y`: The height of the window.
     - `tittle`: The title of the window.

6. **`render_object(obj& obj_)`**:
   - Renders the 3D object onto the screen using SFML.
   - **Parameters**:
     - `obj_`: The object to be rendered.

7. **`render_screen(sf::VertexArray &obj_)`**:
   - A function to handle rendering of `sf::VertexArray` objects to the screen.

---

### **Example Code: Basic Usage of GEP**

The following example demonstrates how to use the functions defined in GEP to load and render a 3D object with transformations.

```cpp
#include "../src/GEP.hpp"

sf::RenderWindow window;

int main()
{
    // Declare an object to hold the 3D object data
    obj obj_;

    // Read object data from files
    read("GAME_DATA/cub.col", "GAME_DATA/cub.col_dt", obj_);

    // Apply camera settings with a 120-degree field of view
    camera(120.0f, obj_);

    // Set up the SFML window with size 800x600 and title "TEST"
    screen(800, 600, "TEST");

    // Main render loop
    while (window.isOpen())
    {
        // Handle events such as closing the window
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        // Render the 3D object to the screen
        render_object(obj_);
    }

    return EXIT_SUCCESS;
}
```

### **Explanation of the Example**

1. **Reading Object Data**:
   - `read("GAME_DATA/cub.col", "GAME_DATA/cub.col_dt", obj_);`: This function reads the 3D object data (vertices and edges) from the files `cub.col` and `cub.col_dt` and loads them into the `obj_` object.

2. **Setting the Camera**:
   - `camera(120.0f, obj_);`: This sets the camera's field of view (FOV) to 120 degrees for the object `obj_`.

3. **Window Initialization**:
   - `screen(800, 600, "TEST");`: Initializes an SFML window with a width of 800 pixels, a height of 600 pixels, and the title "TEST".

4. **Main Event Loop**:
   - The program enters a `while` loop to continually poll events (like closing the window) and render the object. This loop ensures that the graphics are continuously updated and displayed.

5. **Rendering the Object**:
   - `render_object(obj_);`: This function renders the object `obj_` to the screen during each iteration of the event loop.

---

### **Common Workflow**

1. **Define Your Object**:
   - Create an `obj` instance that will hold the object data (vertices and edges).

2. **Load Data**:
   - Use the `read()` function to load the object data from the specified files.

3. **Configure the Camera**:
   - Adjust the camera's field of view (FOV) by calling the `camera()` function.

4. **Create the Window**:
   - Set up the rendering window using the `screen()` function.

5. **Main Loop**:
   - Run a loop where events are handled (e.g., closing the window) and the object is rendered continuously.

---

### **Compilation and Requirements**

To compile a program using GEP, ensure you have the following:

- **SFML Library**: You need SFML to handle rendering.
  - Install SFML: [SFML Downloads](https://www.sfml-dev.org/download.php)
  
- **Compiler**: A C++11-compliant compiler is required (e.g., GCC, Clang, MSVC).
  
**Compilation Command Example** (Linux/GCC):
```sh
clang++ -std=c++17 -I"path/to/sfml/include" -L"path/to/sfml/lib" -o test/test.exe test/main.cpp src/GEP_IOEP.cpp src/GEP_PIPE.cpp src/GEP_TRS.cpp -lsfml-graphics -lsfml-window -lsfml-system
```

---

### **License**

The GEP for Leaft Engine is distributed under the **MIT License**. You can use, modify, and distribute the code as long as you retain the copyright notice and the license text. See the [MIT License](https://opensource.org/licenses/MIT) for more details.

---

### **Conclusion**

The Graphics Engine Pipeline (GEP) for Leaft Engine provides a straightforward way to handle 3D object manipulation and rendering using SFML. By following the documentation and examples, you can integrate and extend this pipeline for your own projects.