### Graphics Engine Pipeline (GEP) - Leaft Engine

Welcome to the **Graphics Engine Pipeline (GEP)** for the **Leaft Engine**! This engine is designed to handle the basic graphics rendering pipeline and provides functions to manipulate 3D objects, manage camera transformations, and render them on a 2D screen.

### Overview

The Leaft Engine's GEP is responsible for handling the graphical objects, their transformations, and displaying them through SFML (Simple and Fast Multimedia Library). This includes object movement, rotation, camera effects, and rendering to the screen.

### Header File: `GEP.hpp`

This header defines the core functionalities of the graphics pipeline.

---

### Key Components

1. **Structures**

   - `obj`: Defines a 3D object with a set of vertices and edges, allowing for 3D transformations and rendering.
     - `vertex_count`: The total number of vertices in the object.
     - `edge_count`: The number of edges connecting the vertices.
     - `vertex`: A vector of vertices, where each vertex is represented as a list of 3D coordinates.
     - `edges`: A vector of edges, each connecting two vertices by their indices.

2. **Functions**

   - `void move(int dx, int dy, int dz, obj& obj_)`: Moves the 3D object by the given offsets in the x, y, and z axes.
   
   - `void rotate(int degrees, int axis, obj& obj_)`: Rotates the object by the specified number of degrees around a given axis (0 = x, 1 = y, 2 = z).

   - `void camera(float fov, obj& obj_)`: Adjusts the object's perspective using a camera with the specified field of view (FOV).

   - `void render_object(obj& obj_)`: Renders the object onto the screen.

   - `void read(const char file_name[], const char file_name_[], obj& obj_)`: Reads the object data from a specified file. This allows for importing 3D object data (vertices and edges).

   - `void screen(int size_x, int size_y, char tittle[])`: Initializes the SFML window with the given width, height, and title.

   - `void render_screen(sf::VertexArray &obj_)`: Renders the object as a SFML `VertexArray` to the screen.

### How It Works

1. **Creating and Modifying Objects**

   You create 3D objects by defining their vertices and edges. You can manipulate these objects using the `move()` and `rotate()` functions. The transformations (translation and rotation) are applied in 3D space, and you can control their behavior through the `obj` structure.

2. **Setting Up the Camera**

   The `camera()` function adjusts the viewing perspective by modifying the field of view (FOV). This is crucial for 3D rendering, as it determines how the object appears when viewed from different distances.

3. **Rendering to the Screen**

   Once the objects are defined and transformed, they are rendered to the screen using the SFML library. You can customize the screen's resolution and title via the `screen()` function. The objects are drawn using `sf::VertexArray`, which is rendered using `render_screen()`.

4. **Reading Object Data**

   The `read()` function allows for importing 3D models by reading the object data from a file. The function expects the file to contain information about the vertices and edges that make up the object.

### Example Usage

```cpp
#include "../src/GEP.hpp"

sf::RenderWindow window;

int main()
{
    obj obj_;
    read("GAME_DATA/cub.col", "GAME_DATA/cub.col_dt", obj_);
    camera(120.0f,obj_);
    screen(800,600,"TEST");
    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
        }
        render_object(obj_);
    }

    return EXIT_SUCCESS;
}
```

### Requirements

- **SFML Library**: This engine relies on SFML for rendering. You need to link SFML's graphics and window modules.
  - Install SFML: [SFML Downloads](https://www.sfml-dev.org/download.php)
  
- **Compiler**: A C++ compiler supporting C++11 or later.

### Additional Notes

- The objects you create using this pipeline are simple 3D representations of vertices and edges. More advanced features like texture mapping, shading, and lighting can be added as the engine evolves.
- The current version does not support real-time interactive lighting or advanced rendering effects.

---

We hope you find the GEP pipeline for Leaft Engine a useful starting point for your 3D rendering needs!